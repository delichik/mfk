package ${GO_PACKAGE_NAME}
#set($ModuleNameUpper=$ModuleName.substring(0,1).toUpperCase() + $ModuleName.substring(1))
#set($ModuleNameLower=$ModuleName.substring(0,1).toLowerCase() + $ModuleName.substring(1))

import (
	"github.com/delichik/my-go-pkg/config"
)


const (
	Module${ModuleNameUpper} = "${ModuleNameLower}"
)

var defaultConfig${ModuleNameUpper} = &Config${ModuleNameUpper}{
}

func init() {
	config.RegisterModuleConfig(Module${ModuleNameUpper}, defaultConfig${ModuleNameUpper})
}

type Config${ModuleNameUpper} struct {
}

func (c *Config${ModuleNameUpper}) Check() error {
	return nil
}

func (c *Config${ModuleNameUpper}) Clone() config.ModuleConfig {
	newObj := *c
	return &newObj
}

func (c *Config${ModuleNameUpper}) Compare(config.ModuleConfig) bool {
	return true
}